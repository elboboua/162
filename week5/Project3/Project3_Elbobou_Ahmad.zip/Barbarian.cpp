/********************************************************************* 
** Description: The implementation file for the Barbarian derived 
*********************************************************************/ 

#include "Barbarian.hpp"
// Passes the strenght, armor, and type to the base constructor
Barbarian::Barbarian() : Character(12,0, "Barbarian") {
};


