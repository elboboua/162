/********************************************************************* 
** Description: The specification file for the Barbarian derived class
*********************************************************************/

#ifndef BARBARIAN_H
#define BARBARIAN_H

#include "Character.hpp"

class Barbarian: public Character {

public:
	Barbarian();
};


#endif // BARBARIAN_H
