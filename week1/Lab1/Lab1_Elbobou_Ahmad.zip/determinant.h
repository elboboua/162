/********************************************************************* 
*** Description: This is the specification file for the determinant function
**********************************************************************/ 

#ifndef DETERMINANT_H
#define DETERMINANT_H	


int determinant(int, int**);




#endif // DETERMINANT_H
