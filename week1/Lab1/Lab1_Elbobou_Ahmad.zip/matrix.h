/********************************************************************* 
*** Description: The header file for the readMatrix function
**********************************************************************/ 



#ifndef MATRIX_H
#define MATRIX_H


void readMatrix(int, int**);


#endif // MATRIX_H
