/*********************************************************************
** Author: Ahmad El-Bobou
** Date: 11-22-2018 
** Description: Lab 9 - working with STL classes 
*********************************************************************/

#include "inputValidation.hpp"
#include "Menu.hpp"

int main () {

	Menu menu;

	menu.loop();


	return 0;
}
