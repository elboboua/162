/*********************************************************************
** Author: Ahmad El-Bobou
** Date: 12-01-2018
** Description: Final Project - 162 Coding Game 
*********************************************************************/

#include "Game.hpp"
#include <iostream>

int main() {

	Game game;
	game.loop();

	return 0;
}
